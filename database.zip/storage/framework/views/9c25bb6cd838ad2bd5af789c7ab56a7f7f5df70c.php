

<?php $__env->startSection('title', 'Relationship Managers List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">All Relationship Managers</h1>
            <div class="row">
                <div class="col-md-6">
                    <a href="<?php echo e(route('relationship_managers.create')); ?>" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus"></i> Add New
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="<?php echo e(route('relationship_managers.export')); ?>" class="btn btn-sm btn-success">
                        <i class="fas fa-check"></i> Export To Excel
                    </a>
                </div>

            </div>

        </div>

        
        <?php echo $__env->make('common.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                
                <form action="<?php echo e(route('relationship_managers.index')); ?>" method="GET" role="search">
                    <div class="input-group-append">
                        <input type="text" placeholder="Search" name="search"
                            class="form-control float-right filter_by_key" value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-default filter_by_click">
                            <i class="fas fa-search"></i>
                        </button>
                        <a href="<?php echo e(route('relationship_managers.index')); ?>" class="btn btn-default filter_by_click">
                            <i class="fas fa-redo"></i>
                        </a>
                    </div>
                </form>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="20%">Name</th>
                                <th width="25%">Email</th>
                                <th width="15%">Mobile</th>
                                <th width="15%">Status</th>
                                <th width="10%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $relationship_managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationship_manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($relationship_manager->name); ?></td>
                                    <td><?php echo e($relationship_manager->email); ?></td>
                                    <td><?php echo e($relationship_manager->mobile_number); ?></td>
                                    <td>
                                        <?php if($relationship_manager->status == 0): ?>
                                            <span class="badge badge-danger">Inactive</span>
                                        <?php elseif($relationship_manager->status == 1): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="display: flex">
                                        <?php if($relationship_manager->status == 0): ?>
                                            <a href="<?php echo e(route('relationship_managers.status', ['relationship_manager_id' => $relationship_manager->id, 'status' => 1])); ?>"
                                                class="btn btn-success m-2">
                                                <i class="fa fa-check"></i>
                                            </a>
                                        <?php elseif($relationship_manager->status == 1): ?>
                                            <a href="<?php echo e(route('relationship_managers.status', ['relationship_manager_id' => $relationship_manager->id, 'status' => 0])); ?>"
                                                class="btn btn-danger m-2">
                                                <i class="fa fa-ban"></i>
                                            </a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('relationship_managers.edit', ['relationship_manager' => $relationship_manager->id])); ?>"
                                            class="btn btn-primary m-2">
                                            <i class="fa fa-pen"></i>
                                        </a>
                                        <a class="btn btn-danger m-2" href="#" data-toggle="modal"
                                            data-target="#deleteModal">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">No Record Found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <?php echo e($relationship_managers->links()); ?>

                </div>
            </div>
        </div>

    </div>
    <?php if(!$relationship_managers->isEmpty()): ?>
        <?php echo $__env->make('relationship_managers.delete-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\test\techtool-laravel-admin\resources\views/relationship_managers/index.blade.php ENDPATH**/ ?>